create view v2 as
select `r`.`s_id` AS `sid`, `su`.`su_name` AS `suname`, `r`.`r_score` AS `score`
from (`db1`.`subject` `su`
         join `db1`.`result` `r` on ((`su`.`su_id` = `r`.`su_id`)));

