create view v1 as
select `a`.`a_id`       AS `aid`,
       `a`.`a_name`     AS `aname`,
       `sc`.`sc_id`     AS `scid`,
       `sc`.`sc_name`   AS `scname`,
       `s`.`s_id`       AS `sid`,
       `s`.`s_name`     AS `name`,
       `s`.`s_sex`      AS `sex`,
       `s`.`s_birthday` AS `birthday`,
       `s`.`s_examnum`  AS `examnum`
from ((`db1`.`area` `a` join `db1`.`school` `sc` on ((`a`.`a_id` = `sc`.`a_id`)))
         join `db1`.`student` `s` on ((`sc`.`sc_id` = `s`.`sc_id`)));

